

public class ejercicio3_DiegaChiola {
	
	
	public static void main(String[] args) {
    //organizacion: clase main Itacademy  
    //clase fundamentos, especializacion (sub clase: backend, fullstack, Data), Proyecto, busqueda. 
  
   
}