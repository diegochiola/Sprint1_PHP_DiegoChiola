public class Itacademy {
    //atributos
    //metodo constructor
    //setter
    //getter
    //metodo propio

}