public class especializacion {
     //atributos
     private String nombre;
     private String descripcion;
 
     //metodo constructor
    //setter
    //getter
    //metodo propio

}