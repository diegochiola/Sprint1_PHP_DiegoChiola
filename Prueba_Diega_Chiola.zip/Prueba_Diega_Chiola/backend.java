public class backend extends especializacion{
    //atributos
    private int sprint = 5;
    //metodo constructor
    
    //setter
    //getter
    //metodo propio
}